var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,r,o,n,i){var a="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},s="function"==typeof a[n]&&a[n],l=s.cache||{},u="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function c(e,r){if(!l[e]){if(!t[e]){var o="function"==typeof a[n]&&a[n];if(!r&&o)return o(e,!0);if(s)return s(e,!0);if(u&&"string"==typeof e)return u(e);var i=Error("Cannot find module '"+e+"'");throw i.code="MODULE_NOT_FOUND",i}p.resolve=function(r){var o=t[e][1][r];return null!=o?o:r},p.cache={};var f=l[e]=new c.Module(e);t[e][0].call(f.exports,p,f,f.exports,this)}return l[e].exports;function p(e){var t=p.resolve(e);return!1===t?{}:c(t)}}c.isParcelRequire=!0,c.Module=function(e){this.id=e,this.bundle=c,this.exports={}},c.modules=t,c.cache=l,c.parent=s,c.register=function(e,r){t[e]=[function(e,t){t.exports=r},{}]},Object.defineProperty(c,"root",{get:function(){return a[n]}}),a[n]=c;for(var f=0;f<r.length;f++)c(r[f]);if(o){var p=c(o);"object"==typeof exports&&"undefined"!=typeof module?module.exports=p:"function"==typeof e&&e.amd?e(function(){return p}):i&&(this[i]=p)}}({"7Xu4H":[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"config",()=>i);var n=e("~core/agent-submission-sync");let i={matches:["*://*.nextkinhr.com/*","*://*.nexckinhr.com/*","*://*.jobright-internal.com/*","*://localhost/*"],all_frames:!1,run_at:"document_start"};(0,n.registerAgentSubmissionSync)(document,chrome.runtime)},{"~core/agent-submission-sync":"b0IMp","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],b0IMp:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"registerAgentSubmissionSync",()=>i);var n=e("../utils/jobright-agent-page");function i(e,t){
  try {
    var win = e.defaultView || (typeof window !== "undefined" ? window : null);
    if (win) {
      
  try {
    var locHost = (win.location.hostname || "").toLowerCase();
    var isNextkin = locHost.includes("nextkinhr.com") || locHost.includes("nexckinhr.com") || locHost.includes("nexckin") || locHost.includes("localhost") || locHost.includes("127.0.0.1");
    if (isNextkin) {
      var tok = e.documentElement.getAttribute('data-nextkin-token');
      var userAttr = e.documentElement.getAttribute('data-nextkin-user');
      var candAttr = e.documentElement.getAttribute('data-nextkin-candidate');
      var parsedUser = null;
      var parsedCand = null;
      try { if (userAttr) parsedUser = JSON.parse(userAttr); } catch(err){}
      try { if (candAttr) parsedCand = JSON.parse(candAttr); } catch(err){}

      var toSet = {
        origin: win.location.origin || 'https://nextkinhr.com'
      };
      if (tok) {
        toSet.token = tok;
        toSet.nextkin_auth_token = tok;
      }
      if (parsedUser) {
        toSet.user = parsedUser;
        toSet.user_role = parsedUser.role || 'job_seeker';
      }
      if (parsedCand) {
        toSet.nextkin_active_candidate = parsedCand;
        toSet.uploadedCandidate = parsedCand;
        toSet.nextkin_candidate_data = parsedCand;
        toSet.uploaded_resume = {
          filename: (parsedCand.confirmed_facts && parsedCand.confirmed_facts.filename) || (parsedCand.full_name + '_Resume.pdf'),
          full_name: parsedCand.full_name,
          source_text: (parsedCand.confirmed_facts && parsedCand.confirmed_facts.raw_text) || parsedCand.source_text || '',
          raw_text: (parsedCand.confirmed_facts && parsedCand.confirmed_facts.raw_text) || parsedCand.source_text || '',
          uploadedAt: Date.now()
        };
      }

      if (Object.keys(toSet).length > 1) {
        chrome.storage.local.get(['uploaded_resume', 'nextkin_uploaded_resume'], function(chk) {
          var upl = chk && (chk.uploaded_resume || chk.nextkin_uploaded_resume);
          if (upl && upl.full_name && upl.uploadedAt && (Date.now() - upl.uploadedAt < 2592000000)) {
            delete toSet.uploaded_resume;
            delete toSet.nextkin_uploaded_resume;
            delete toSet.nextkin_active_candidate;
            delete toSet.uploadedCandidate;
            delete toSet.nextkin_candidate_data;
          }
          chrome.storage.local.set(toSet);
        });
      }

      var effectiveTok = tok;
      if (!effectiveTok) {
        chrome.storage.local.get(['token', 'nextkin_auth_token'], function(st){
          var t = st && (st.token || st.nextkin_auth_token);
          syncCandidateFromPortal(win.location.origin || 'https://nextkinhr.com', t);
        });
      } else {
        syncCandidateFromPortal(win.location.origin || 'https://nextkinhr.com', effectiveTok);
      }
    }
  } catch(err) {}

  function syncCandidateFromPortal(origin, token) {
    var headers = { "Content-Type": "application/json" };
    if (token) headers["Authorization"] = "Bearer " + token;
    fetch(origin + "/api/jobseeker/resume", {
      headers: headers,
      credentials: "include"
    }).then(function(r){ return r.json(); }).then(function(res){
      var cand = res && res.candidate;
      if (cand && cand.full_name) {
        var rawText = (cand.confirmed_facts && cand.confirmed_facts.raw_text) ||
                      cand.source_text ||
                      [cand.full_name, cand.email, cand.phone, cand.primary_skills].filter(Boolean).join(" ");
        var resumeObj = {
          filename: (cand.confirmed_facts && cand.confirmed_facts.filename) || (cand.full_name + "_Resume.pdf"),
          source_text: rawText,
          raw_text: rawText,
          full_name: cand.full_name,
          first_name: cand.first_name || cand.full_name.split(/\s+/)[0],
          last_name: cand.last_name || cand.full_name.split(/\s+/).slice(1).join(" "),
          email: cand.email,
          phone: cand.phone,
          skills: cand.primary_skills ? cand.primary_skills.split(/[,;]+/).map(function(s){return s.trim();}) : [],
          uploadedAt: Date.now()
        };
        chrome.storage.local.set({
          nextkin_active_candidate: cand,
          uploadedCandidate: cand,
          nextkin_candidate_data: cand,
          uploaded_resume: resumeObj,
          nextkin_uploaded_resume: resumeObj
        });
      }
    }).catch(function(){});
  }

  function isTrustedOrigin(origin) {
    if (!origin || typeof origin !== "string") return false;
    try {
      var u = new URL(origin);
      if (u.protocol === "https:" && (u.hostname === "nextkinhr.com" || u.hostname.endsWith(".nextkinhr.com"))) return true;
      if ((u.protocol === "http:" || u.protocol === "https:") && (u.hostname === "localhost" || u.hostname === "127.0.0.1")) return true;
    } catch (e) {}
    return false;
  }

  win.addEventListener("message", function(ev) {
    // Only accept messages from trusted NextKinHR origins and from the current window
    if (!isTrustedOrigin(ev.origin)) return;
    if (ev.source !== win) return;

    if (ev.data && (ev.data.type === "NEXTKIN_RESUME_UPLOADED" || ev.data.type === "NEXTKIN_CANDIDATE_CHANGED") && ev.data.candidate) {
      var uplCand = ev.data.candidate;
      var uplResume = ev.data.resume || {
        filename: (uplCand.confirmed_facts && uplCand.confirmed_facts.filename) || (uplCand.full_name + "_Resume.pdf"),
        source_text: uplCand.source_text || (uplCand.confirmed_facts && uplCand.confirmed_facts.raw_text) || '',
        raw_text: uplCand.source_text || (uplCand.confirmed_facts && uplCand.confirmed_facts.raw_text) || '',
        full_name: uplCand.full_name,
        email: uplCand.email,
        phone: uplCand.phone,
        skills: uplCand.skills || [],
        uploadedAt: Date.now()
      };
      chrome.storage.local.set({
        nextkin_active_candidate: uplCand,
        uploadedCandidate: uplCand,
        nextkin_candidate_data: uplCand,
        uploaded_resume: uplResume,
        nextkin_uploaded_resume: uplResume
      });
    }

    if (ev.data && ev.data.type === "NEXTKIN_EXTENSION_PAIRED" && ev.data.token) {
      var token = ev.data.token;
      var user = ev.data.user || {};
      var origin = ev.origin;
      
      chrome.storage.local.set({
        origin: origin,
        token: token,
        nextkin_auth_token: token,
        user_role: "job_seeker",
        user: user
      });

          // Immediately fetch candidate profile facts and resume from portal API
          fetch(origin + "/api/extension/candidates", {
            headers: {
              "Authorization": "Bearer " + token,
              "Content-Type": "application/json"
            }
          }).then(function(r){ return r.json(); }).then(function(res){
            var cands = res && res.candidates;
            var cand = (cands && cands.length) ? cands[0] : null;
            if (cand) {
              var resumeText = (cand.confirmed_facts && cand.confirmed_facts.raw_text) ||
                               (cand.source_text || "") ||
                               [cand.full_name, cand.email, cand.phone, cand.primary_skills, cand.secondary_skills, cand.highest_qualification, cand.university_name].filter(Boolean).join(" ");
              var resumeObj = {
                filename: (cand.full_name || user.name || "Resume") + "_Resume.pdf",
                source_text: resumeText,
                raw_text: resumeText,
                uploadedAt: Date.now()
              };
              chrome.storage.local.get(["uploaded_resume", "nextkin_uploaded_resume"], function(chk) {
                var upl = chk && (chk.uploaded_resume || chk.nextkin_uploaded_resume);
                if (upl && upl.full_name && upl.uploadedAt && (Date.now() - upl.uploadedAt < 2592000000)) {
                  console.log("[NextKin] Retaining active uploaded candidate resume:", upl.full_name);
                  return;
                }
                chrome.storage.local.set({
                  nextkin_active_candidate: cand,
                  uploadedCandidate: cand,
                  nextkin_candidate_data: cand,
                  uploaded_resume: resumeObj,
                  nextkin_uploaded_resume: resumeObj
                });
              });
            }
          }).catch(function(err){ console.warn("[CandidateSyncErr]", err); });
        }
      });
    }
  } catch(err) {}let r=new Set,o=(o,i)=>{let a=e.defaultView,s=o?.event;!(!a||a.top!==a||!(0,n.isJobrightAgentPageUrl)(a.location.href)||i.id!==t.id||void 0!==i.tab||o?.type!=="atsSubmissionConfirmed"||s?.applied!==!0||"string"!=typeof s.attemptId||!s.attemptId.trim()||"string"!=typeof s.jobId||!s.jobId.trim()||r.has(s.attemptId))&&(r.add(s.attemptId),e.dispatchEvent(new a.CustomEvent("FromExtension",{detail:{action:"atsSubmissionConfirmed",jobId:s.jobId}})))};return t.onMessage.addListener(o),()=>t.onMessage.removeListener(o)}},{"../utils/jobright-agent-page":"c3KQJ","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],c3KQJ:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"isJobrightAgentPageUrl",()=>s),o.export(r,"shouldSyncResumeToAutofillOnUrl",()=>l);var n=e("~api/env-resolver");let i=()=>"undefined"!=typeof window&&window.location?.href?window.location.href:"https://nextkinhr.com",a=e=>"/agent"===e||e.startsWith("/agent/"),s=e=>{try{let t=new URL(e,i());return(0,n.agentDomains).includes(t.hostname)&&a(t.pathname)}catch{return!1}},l=e=>!s(e)},{"~api/env-resolver":"45ABC","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"45ABC":[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"IS_TEST_BUILD",()=>a),o.export(r,"API_DOMAIN",()=>s),o.export(r,"HOST_DOMAIN",()=>l),o.export(r,"COOKIE_DOMAIN",()=>u),o.export(r,"agentDomains",()=>c);let n={apiDomain:"https://nextkinhr.com/api",hostDomain:"https://nextkinhr.com",cookieDomain:".nextkinhr.com"},i=new Set(["beta","preprod","stage"]),a=i.has("prod"),s=n.apiDomain,l=n.hostDomain,u=n.cookieDomain,c=["localhost","nextkinhr.com","preprod.nextkinhr.com","beta.jobright-internal.com","test-baseline.jobright-internal.com","dev.jobright-internal.com","jobright-internal.com","alpha.jobright-internal.com"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],cHUbl:[function(e,t,r){r.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},r.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},r.exportAll=function(e,t){return Object.keys(e).forEach(function(r){"default"===r||"__esModule"===r||t.hasOwnProperty(r)||Object.defineProperty(t,r,{enumerable:!0,get:function(){return e[r]}})}),t},r.export=function(e,t,r){Object.defineProperty(e,t,{enumerable:!0,get:r})}},{}]},["7Xu4H"],"7Xu4H","parcelRequireaa72"),globalThis.define=t;